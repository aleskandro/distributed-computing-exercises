package dsbd2020.lab.tokenchain.datamodel;

import dsbd2020.lab.tokenchain.entities.Log;
import org.springframework.data.repository.CrudRepository;

public interface LogRepository extends CrudRepository<Log,Integer> {

}
