package dsbd2020.lab.tokenchain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokenchainApplicationTests {

    @Test
    void contextLoads() {
    }

}
